#ifndef GESTORPAQUETES_H
#define GESTORPAQUETES_H

#include "Paquete.h"
#include <queue>
#include <stack>
#include <vector>

class GestorPaquetes {
private:
    std::queue<Paquete> colaPendientes;
    std::stack<Paquete> pilaUrgentes;
    int contadorId;

public:
    GestorPaquetes();

    // Cola (pendientes)
    void agregarPendiente(const std::string& descripcion, const std::string& destino);
    bool procesarPendiente();

    // Pila (urgentes)
    void agregarUrgente(const std::string& descripcion, const std::string& destino);
    bool procesarUrgente();

    // Consultas
    int cantidadPendientes() const;
    int cantidadUrgentes() const;
    void mostrarEstado() const;
};

#endif
