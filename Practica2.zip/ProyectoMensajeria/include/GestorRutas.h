#ifndef GESTORRUTAS_H
#define GESTORRUTAS_H

#include <string>
#include <vector>
#include <map>
#include <tuple>

// Estructura para la matriz dispersa (rutas prioritarias)
struct EntradaDispersa {
    int fila;
    int columna;
    double valor;
    EntradaDispersa(int f, int c, double v) : fila(f), columna(c), valor(v) {}
};

class GestorRutas {
private:
    // Matriz 1D: distancias entre puntos relevantes
    std::vector<double> distancias1D;
    std::vector<std::string> etiquetas1D;

    // Matriz 2D: tiempos estimados entre ciudades (NxN)
    std::vector<std::vector<double>> tiempos2D;
    std::vector<std::string> ciudades2D;

    // Matriz dispersa: rutas prioritarias
    std::vector<EntradaDispersa> matrizDispersa;
    std::vector<std::string> ciudadesDispersa;

    // Cola circular: puntos de control del camion
    std::vector<std::string> puntosControl;
    int capacidadCircular;
    int frente;
    int fin;
    int conteoCircular;

public:
    GestorRutas();

    // Matriz 1D
    void agregarDistancia(const std::string& etiqueta, double distancia);
    void mostrarDistancias() const;

    // Matriz 2D
    void inicializarCiudades2D(const std::vector<std::string>& ciudades);
    void setTiempo(const std::string& origen, const std::string& destino, double tiempo);
    void mostrarTiempos() const;

    // Matriz dispersa
    void agregarRutaPrioritaria(const std::string& origen, const std::string& destino, double prioridad);
    void mostrarMatrizDispersa() const;

    // Cola circular
    void inicializarColaCircular(int capacidad);
    void cargarPuntoControl(const std::string& punto);
    void avanzarCamion();
    void mostrarPosicion() const;
    void mostrarColaCircular() const;
};

#endif
