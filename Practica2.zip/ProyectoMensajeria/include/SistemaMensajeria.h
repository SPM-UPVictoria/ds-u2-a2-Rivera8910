#ifndef SISTEMAMENSAJERIA_H
#define SISTEMAMENSAJERIA_H

#include "Ruta.h"
#include "GestorPaquetes.h"
#include "GestorRutas.h"

class SistemaMensajeria {
private:
    Ruta ruta;
    GestorPaquetes gestorPaquetes;
    GestorRutas gestorRutas;

    void menuGestionRutas();
    void menuGestionPaquetes();
    void menuCola();
    void menuPila();
    void menuSimulacionCamion();
    void menuMatrices();
    void mostrarResumenGeneral();

public:
    SistemaMensajeria();
    void ejecutar();
    void cargarDatosDemostracion();
};

#endif
