#include "GestorPaquetes.h"
#include <iostream>

GestorPaquetes::GestorPaquetes() : contadorId(1) {}

void GestorPaquetes::agregarPendiente(const std::string& descripcion, const std::string& destino) {
    Paquete p(contadorId++, descripcion, destino, false);
    colaPendientes.push(p);
    std::cout << "  [+] Paquete #" << (contadorId - 1) << " agregado a la cola de pendientes.\n";
}

bool GestorPaquetes::procesarPendiente() {
    if (colaPendientes.empty()) {
        std::cout << "  [!] No hay paquetes pendientes en la cola.\n";
        return false;
    }
    Paquete p = colaPendientes.front();
    colaPendientes.pop();
    std::cout << "  [>>] Procesando paquete pendiente:\n";
    p.mostrar();
    return true;
}

void GestorPaquetes::agregarUrgente(const std::string& descripcion, const std::string& destino) {
    Paquete p(contadorId++, descripcion, destino, true);
    pilaUrgentes.push(p);
    std::cout << "  [+] Paquete urgente #" << (contadorId - 1) << " apilado.\n";
}

bool GestorPaquetes::procesarUrgente() {
    if (pilaUrgentes.empty()) {
        std::cout << "  [!] No hay paquetes urgentes en la pila.\n";
        return false;
    }
    Paquete p = pilaUrgentes.top();
    pilaUrgentes.pop();
    std::cout << "  [>>] Procesando paquete URGENTE (LIFO):\n";
    p.mostrar();
    return true;
}

int GestorPaquetes::cantidadPendientes() const { return (int)colaPendientes.size(); }
int GestorPaquetes::cantidadUrgentes() const { return (int)pilaUrgentes.size(); }

void GestorPaquetes::mostrarEstado() const {
    std::cout << "  Cola pendientes: " << colaPendientes.size() << " paquete(s)\n";
    std::cout << "  Pila urgentes:   " << pilaUrgentes.size() << " paquete(s)\n";

    // Mostrar cola (copia temporal)
    if (!colaPendientes.empty()) {
        std::cout << "  -- Pendientes (frente -> fondo) --\n";
        std::queue<Paquete> copia = colaPendientes;
        while (!copia.empty()) {
            copia.front().mostrar();
            copia.pop();
        }
    }

    // Mostrar pila (copia temporal)
    if (!pilaUrgentes.empty()) {
        std::cout << "  -- Urgentes (tope -> fondo) --\n";
        std::stack<Paquete> copia = pilaUrgentes;
        while (!copia.empty()) {
            copia.top().mostrar();
            copia.pop();
        }
    }
}
