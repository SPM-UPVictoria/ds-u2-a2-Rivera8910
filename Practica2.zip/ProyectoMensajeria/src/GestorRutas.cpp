#include "GestorRutas.h"
#include <iostream>
#include <iomanip>
#include <algorithm>

GestorRutas::GestorRutas()
    : capacidadCircular(10), frente(0), fin(-1), conteoCircular(0) {
    puntosControl.resize(capacidadCircular, "");
}

// ===================== Matriz 1D =====================

void GestorRutas::agregarDistancia(const std::string& etiqueta, double distancia) {
    etiquetas1D.push_back(etiqueta);
    distancias1D.push_back(distancia);
    std::cout << "  [+] Distancia agregada: " << etiqueta << " = " << distancia << " km\n";
}

void GestorRutas::mostrarDistancias() const {
    if (distancias1D.empty()) {
        std::cout << "  [!] No hay distancias registradas.\n";
        return;
    }
    std::cout << "  -- Matriz 1D: Distancias --\n";
    std::cout << "  " << std::left << std::setw(25) << "Tramo" << std::setw(12) << "Distancia (km)" << "\n";
    std::cout << "  " << std::string(37, '-') << "\n";
    for (size_t i = 0; i < distancias1D.size(); i++) {
        std::cout << "  " << std::setw(25) << etiquetas1D[i] << std::setw(12) << distancias1D[i] << "\n";
    }
}

// ===================== Matriz 2D =====================

void GestorRutas::inicializarCiudades2D(const std::vector<std::string>& ciudades) {
    ciudades2D = ciudades;
    int n = (int)ciudades.size();
    tiempos2D.assign(n, std::vector<double>(n, 0.0));
    std::cout << "  [+] Matriz 2D inicializada para " << n << " ciudades.\n";
}

void GestorRutas::setTiempo(const std::string& origen, const std::string& destino, double tiempo) {
    auto itO = std::find(ciudades2D.begin(), ciudades2D.end(), origen);
    auto itD = std::find(ciudades2D.begin(), ciudades2D.end(), destino);
    if (itO == ciudades2D.end() || itD == ciudades2D.end()) {
        std::cout << "  [!] Ciudad no encontrada en la matriz 2D.\n";
        return;
    }
    int i = (int)(itO - ciudades2D.begin());
    int j = (int)(itD - ciudades2D.begin());
    tiempos2D[i][j] = tiempo;
    tiempos2D[j][i] = tiempo;
    std::cout << "  [+] Tiempo " << origen << " <-> " << destino << " = " << tiempo << " hrs\n";
}

void GestorRutas::mostrarTiempos() const {
    if (ciudades2D.empty()) {
        std::cout << "  [!] Matriz 2D vacia.\n";
        return;
    }
    int n = (int)ciudades2D.size();
    std::cout << "  -- Matriz 2D: Tiempos estimados (horas) --\n";
    std::cout << "  " << std::setw(12) << "";
    for (auto& c : ciudades2D) std::cout << std::setw(12) << c.substr(0, 10);
    std::cout << "\n  " << std::string(12 + 12 * n, '-') << "\n";
    for (int i = 0; i < n; i++) {
        std::cout << "  " << std::setw(12) << ciudades2D[i].substr(0, 10);
        for (int j = 0; j < n; j++) {
            if (tiempos2D[i][j] == 0.0 && i != j)
                std::cout << std::setw(12) << "-";
            else
                std::cout << std::setw(12) << tiempos2D[i][j];
        }
        std::cout << "\n";
    }
}

// ===================== Matriz Dispersa =====================

void GestorRutas::agregarRutaPrioritaria(const std::string& origen, const std::string& destino, double prioridad) {
    // Registrar ciudades si no existen
    if (std::find(ciudadesDispersa.begin(), ciudadesDispersa.end(), origen) == ciudadesDispersa.end())
        ciudadesDispersa.push_back(origen);
    if (std::find(ciudadesDispersa.begin(), ciudadesDispersa.end(), destino) == ciudadesDispersa.end())
        ciudadesDispersa.push_back(destino);

    int f = (int)(std::find(ciudadesDispersa.begin(), ciudadesDispersa.end(), origen) - ciudadesDispersa.begin());
    int c = (int)(std::find(ciudadesDispersa.begin(), ciudadesDispersa.end(), destino) - ciudadesDispersa.begin());
    matrizDispersa.emplace_back(f, c, prioridad);
    std::cout << "  [+] Ruta prioritaria: " << origen << " -> " << destino << " (prioridad " << prioridad << ")\n";
}

void GestorRutas::mostrarMatrizDispersa() const {
    if (matrizDispersa.empty()) {
        std::cout << "  [!] No hay rutas prioritarias registradas.\n";
        return;
    }
    std::cout << "  -- Matriz Dispersa: Rutas Prioritarias --\n";
    std::cout << "  Total de entradas no cero: " << matrizDispersa.size() << "\n";
    std::cout << "  " << std::left << std::setw(15) << "Origen"
              << std::setw(15) << "Destino"
              << std::setw(10) << "Prioridad" << "\n";
    std::cout << "  " << std::string(40, '-') << "\n";
    for (auto& e : matrizDispersa) {
        std::string origen  = (e.fila < (int)ciudadesDispersa.size()) ? ciudadesDispersa[e.fila]   : "?";
        std::string destino = (e.columna < (int)ciudadesDispersa.size()) ? ciudadesDispersa[e.columna] : "?";
        std::cout << "  " << std::setw(15) << origen
                  << std::setw(15) << destino
                  << std::setw(10) << e.valor << "\n";
    }
}

// ===================== Cola Circular =====================

void GestorRutas::inicializarColaCircular(int capacidad) {
    capacidadCircular = capacidad;
    puntosControl.assign(capacidad, "");
    frente = 0; fin = -1; conteoCircular = 0;
    std::cout << "  [+] Cola circular inicializada con capacidad " << capacidad << ".\n";
}

void GestorRutas::cargarPuntoControl(const std::string& punto) {
    if (conteoCircular >= capacidadCircular) {
        std::cout << "  [!] Cola circular llena. Capacidad maxima: " << capacidadCircular << "\n";
        return;
    }
    fin = (fin + 1) % capacidadCircular;
    puntosControl[fin] = punto;
    conteoCircular++;
    std::cout << "  [+] Punto de control '" << punto << "' cargado.\n";
}

void GestorRutas::avanzarCamion() {
    if (conteoCircular == 0) {
        std::cout << "  [!] No hay puntos de control cargados.\n";
        return;
    }
    std::string actual = puntosControl[frente];
    frente = (frente + 1) % capacidadCircular;
    // Circular: reinsertar al fondo
    fin = (fin + 1) % capacidadCircular;
    puntosControl[fin] = actual;
    std::cout << "  [>>] Camion avanza. Punto anterior: '" << actual
              << "' | Siguiente: '" << puntosControl[frente] << "'\n";
}

void GestorRutas::mostrarPosicion() const {
    if (conteoCircular == 0) {
        std::cout << "  [!] Cola circular vacia.\n";
        return;
    }
    std::cout << "  Posicion actual del camion: '" << puntosControl[frente] << "'\n";
}

void GestorRutas::mostrarColaCircular() const {
    if (conteoCircular == 0) {
        std::cout << "  [!] Cola circular vacia.\n";
        return;
    }
    std::cout << "  -- Cola Circular (puntos de control) --\n";
    std::cout << "  Capacidad: " << capacidadCircular << " | Activos: " << conteoCircular << "\n";
    for (int i = 0; i < conteoCircular; i++) {
        int idx = (frente + i) % capacidadCircular;
        std::cout << "    [" << i + 1 << "] " << puntosControl[idx];
        if (i == 0) std::cout << "  <-- POSICION ACTUAL";
        std::cout << "\n";
    }
}
