#include "Paquete.h"
#include <iostream>

Paquete::Paquete(int id, const std::string& descripcion, const std::string& destino, bool urgente)
    : id(id), descripcion(descripcion), destino(destino), urgente(urgente) {}

void Paquete::mostrar() const {
    std::cout << "    Paquete #" << id
              << " | Destino: " << destino
              << " | Desc: " << descripcion
              << (urgente ? " [URGENTE]" : " [normal]") << "\n";
}
