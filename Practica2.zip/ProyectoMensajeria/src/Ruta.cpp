#include "Ruta.h"
#include <iostream>

Ruta::Ruta() : cabeza(nullptr), tamano(0), contadorId(1) {}

Ruta::~Ruta() {
    Ciudad* actual = cabeza;
    while (actual != nullptr) {
        Ciudad* siguiente = actual->siguiente;
        delete actual;
        actual = siguiente;
    }
}

void Ruta::agregarCiudad(const std::string& nombre) {
    Ciudad* nueva = new Ciudad(nombre, contadorId++);
    if (cabeza == nullptr) {
        cabeza = nueva;
    } else {
        Ciudad* actual = cabeza;
        while (actual->siguiente != nullptr) {
            actual = actual->siguiente;
        }
        actual->siguiente = nueva;
    }
    tamano++;
    std::cout << "  [+] Ciudad '" << nombre << "' agregada a la ruta.\n";
}

bool Ruta::eliminarPorNombre(const std::string& nombre) {
    if (cabeza == nullptr) return false;

    if (cabeza->nombre == nombre) {
        Ciudad* temp = cabeza;
        cabeza = cabeza->siguiente;
        delete temp;
        tamano--;
        std::cout << "  [-] Ciudad '" << nombre << "' eliminada de la ruta.\n";
        return true;
    }

    Ciudad* actual = cabeza;
    while (actual->siguiente != nullptr) {
        if (actual->siguiente->nombre == nombre) {
            Ciudad* temp = actual->siguiente;
            actual->siguiente = temp->siguiente;
            delete temp;
            tamano--;
            std::cout << "  [-] Ciudad '" << nombre << "' eliminada de la ruta.\n";
            return true;
        }
        actual = actual->siguiente;
    }
    std::cout << "  [!] Ciudad '" << nombre << "' no encontrada.\n";
    return false;
}

bool Ruta::eliminarPorPosicion(int posicion) {
    if (posicion < 1 || posicion > tamano) {
        std::cout << "  [!] Posicion invalida.\n";
        return false;
    }

    if (posicion == 1) {
        Ciudad* temp = cabeza;
        cabeza = cabeza->siguiente;
        std::cout << "  [-] Ciudad '" << temp->nombre << "' (pos " << posicion << ") eliminada.\n";
        delete temp;
        tamano--;
        return true;
    }

    Ciudad* actual = cabeza;
    for (int i = 1; i < posicion - 1; i++) {
        actual = actual->siguiente;
    }
    Ciudad* temp = actual->siguiente;
    actual->siguiente = temp->siguiente;
    std::cout << "  [-] Ciudad '" << temp->nombre << "' (pos " << posicion << ") eliminada.\n";
    delete temp;
    tamano--;
    return true;
}

void Ruta::mostrarRuta() const {
    if (cabeza == nullptr) {
        std::cout << "  [!] La ruta esta vacia.\n";
        return;
    }
    std::cout << "  Ruta actual (" << tamano << " ciudades):\n";
    Ciudad* actual = cabeza;
    int pos = 1;
    while (actual != nullptr) {
        std::cout << "    " << pos++ << ". [ID:" << actual->id << "] " << actual->nombre;
        if (actual->siguiente) std::cout << " --> ";
        actual = actual->siguiente;
    }
    std::cout << "\n";
}

int Ruta::getTamano() const { return tamano; }
Ciudad* Ruta::getCabeza() const { return cabeza; }
