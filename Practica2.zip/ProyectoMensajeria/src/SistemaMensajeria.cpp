#include "SistemaMensajeria.h"
#include <iostream>
#include <string>
#include <limits>

SistemaMensajeria::SistemaMensajeria() {}

void SistemaMensajeria::cargarDatosDemostracion() {
    std::cout << "\n  [*] Cargando datos de demostracion...\n";

    // Ruta inicial
    ruta.agregarCiudad("Ciudad Victoria");
    ruta.agregarCiudad("Monterrey");
    ruta.agregarCiudad("Saltillo");
    ruta.agregarCiudad("San Luis Potosi");

    // Paquetes pendientes
    gestorPaquetes.agregarPendiente("Electrodomesticos", "Monterrey");
    gestorPaquetes.agregarPendiente("Documentos legales", "Saltillo");
    gestorPaquetes.agregarUrgente("Medicamentos", "San Luis Potosi");
    gestorPaquetes.agregarUrgente("Material quirurgico", "Monterrey");

    // Matriz 1D: distancias
    gestorRutas.agregarDistancia("Victoria->Monterrey", 220.0);
    gestorRutas.agregarDistancia("Monterrey->Saltillo", 87.5);
    gestorRutas.agregarDistancia("Saltillo->SLP", 312.0);
    gestorRutas.agregarDistancia("Victoria->SLP", 545.0);

    // Matriz 2D: tiempos
    std::vector<std::string> ciudades = {"Victoria", "Monterrey", "Saltillo", "SLP"};
    gestorRutas.inicializarCiudades2D(ciudades);
    gestorRutas.setTiempo("Victoria", "Monterrey", 2.5);
    gestorRutas.setTiempo("Monterrey", "Saltillo", 1.0);
    gestorRutas.setTiempo("Saltillo", "SLP", 3.5);
    gestorRutas.setTiempo("Victoria", "SLP", 6.0);

    // Matriz dispersa
    gestorRutas.agregarRutaPrioritaria("Victoria", "Monterrey", 9.5);
    gestorRutas.agregarRutaPrioritaria("Monterrey", "SLP", 8.0);
    gestorRutas.agregarRutaPrioritaria("Victoria", "Saltillo", 7.2);

    // Cola circular
    gestorRutas.inicializarColaCircular(6);
    gestorRutas.cargarPuntoControl("Base Central");
    gestorRutas.cargarPuntoControl("Peaje Norte");
    gestorRutas.cargarPuntoControl("Monterrey Centro");
    gestorRutas.cargarPuntoControl("Peaje Sur");
    gestorRutas.cargarPuntoControl("Bodega Saltillo");

    std::cout << "  [*] Datos de demostracion cargados.\n\n";
}

void SistemaMensajeria::menuGestionRutas() {
    int op;
    do {
        std::cout << "\n+-- Gestion de Rutas (Lista Enlazada) ----------------+\n";
        std::cout << "| 1. Agregar ciudad al final                          |\n";
        std::cout << "| 2. Eliminar ciudad por nombre                       |\n";
        std::cout << "| 3. Eliminar ciudad por posicion                     |\n";
        std::cout << "| 4. Mostrar ruta completa                            |\n";
        std::cout << "| 0. Regresar                                         |\n";
        std::cout << "+-----------------------------------------------------+\n";
        std::cout << "  Opcion: ";
        std::cin >> op;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        if (op == 1) {
            std::string nombre;
            std::cout << "  Nombre de la ciudad: ";
            std::getline(std::cin, nombre);
            ruta.agregarCiudad(nombre);
        } else if (op == 2) {
            std::string nombre;
            std::cout << "  Nombre de la ciudad a eliminar: ";
            std::getline(std::cin, nombre);
            ruta.eliminarPorNombre(nombre);
        } else if (op == 3) {
            int pos;
            std::cout << "  Posicion a eliminar: ";
            std::cin >> pos;
            ruta.eliminarPorPosicion(pos);
        } else if (op == 4) {
            ruta.mostrarRuta();
        }
    } while (op != 0);
}

void SistemaMensajeria::menuCola() {
    int op;
    do {
        std::cout << "\n+-- Cola: Paquetes Pendientes -------------------------+\n";
        std::cout << "| 1. Agregar paquete pendiente                        |\n";
        std::cout << "| 2. Procesar siguiente pendiente (FIFO)              |\n";
        std::cout << "| 3. Ver estado                                       |\n";
        std::cout << "| 0. Regresar                                         |\n";
        std::cout << "+-----------------------------------------------------+\n";
        std::cout << "  Opcion: ";
        std::cin >> op;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        if (op == 1) {
            std::string desc, dest;
            std::cout << "  Descripcion: "; std::getline(std::cin, desc);
            std::cout << "  Destino: ";     std::getline(std::cin, dest);
            gestorPaquetes.agregarPendiente(desc, dest);
        } else if (op == 2) {
            gestorPaquetes.procesarPendiente();
        } else if (op == 3) {
            gestorPaquetes.mostrarEstado();
        }
    } while (op != 0);
}

void SistemaMensajeria::menuPila() {
    int op;
    do {
        std::cout << "\n+-- Pila: Paquetes Urgentes ---------------------------+\n";
        std::cout << "| 1. Agregar paquete urgente                          |\n";
        std::cout << "| 2. Procesar paquete urgente (LIFO)                  |\n";
        std::cout << "| 3. Ver estado                                       |\n";
        std::cout << "| 0. Regresar                                         |\n";
        std::cout << "+-----------------------------------------------------+\n";
        std::cout << "  Opcion: ";
        std::cin >> op;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        if (op == 1) {
            std::string desc, dest;
            std::cout << "  Descripcion: "; std::getline(std::cin, desc);
            std::cout << "  Destino: ";     std::getline(std::cin, dest);
            gestorPaquetes.agregarUrgente(desc, dest);
        } else if (op == 2) {
            gestorPaquetes.procesarUrgente();
        } else if (op == 3) {
            gestorPaquetes.mostrarEstado();
        }
    } while (op != 0);
}

void SistemaMensajeria::menuGestionPaquetes() {
    int op;
    do {
        std::cout << "\n+-- Gestion de Paquetes ------------------------------+\n";
        std::cout << "| 1. Cola de pendientes                               |\n";
        std::cout << "| 2. Pila de urgentes                                 |\n";
        std::cout << "| 0. Regresar                                         |\n";
        std::cout << "+-----------------------------------------------------+\n";
        std::cout << "  Opcion: ";
        std::cin >> op;
        if (op == 1) menuCola();
        else if (op == 2) menuPila();
    } while (op != 0);
}

void SistemaMensajeria::menuSimulacionCamion() {
    int op;
    do {
        std::cout << "\n+-- Simulacion: Cola Circular del Camion -------------+\n";
        std::cout << "| 1. Cargar punto de control                          |\n";
        std::cout << "| 2. Avanzar camion (siguiente punto)                 |\n";
        std::cout << "| 3. Ver posicion actual                              |\n";
        std::cout << "| 4. Ver cola completa                                |\n";
        std::cout << "| 5. Re-inicializar cola circular                     |\n";
        std::cout << "| 0. Regresar                                         |\n";
        std::cout << "+-----------------------------------------------------+\n";
        std::cout << "  Opcion: ";
        std::cin >> op;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        if (op == 1) {
            std::string punto;
            std::cout << "  Nombre del punto de control: ";
            std::getline(std::cin, punto);
            gestorRutas.cargarPuntoControl(punto);
        } else if (op == 2) {
            gestorRutas.avanzarCamion();
        } else if (op == 3) {
            gestorRutas.mostrarPosicion();
        } else if (op == 4) {
            gestorRutas.mostrarColaCircular();
        } else if (op == 5) {
            int cap;
            std::cout << "  Capacidad de la nueva cola: ";
            std::cin >> cap;
            gestorRutas.inicializarColaCircular(cap);
        }
    } while (op != 0);
}

void SistemaMensajeria::menuMatrices() {
    int op;
    do {
        std::cout << "\n+-- Manejo de Matrices --------------------------------+\n";
        std::cout << "| 1. Agregar distancia (Matriz 1D)                    |\n";
        std::cout << "| 2. Ver distancias (Matriz 1D)                       |\n";
        std::cout << "| 3. Agregar tiempo entre ciudades (Matriz 2D)        |\n";
        std::cout << "| 4. Ver tiempos (Matriz 2D)                          |\n";
        std::cout << "| 5. Agregar ruta prioritaria (Matriz Dispersa)       |\n";
        std::cout << "| 6. Ver rutas prioritarias (Matriz Dispersa)         |\n";
        std::cout << "| 0. Regresar                                         |\n";
        std::cout << "+-----------------------------------------------------+\n";
        std::cout << "  Opcion: ";
        std::cin >> op;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        if (op == 1) {
            std::string etiq; double dist;
            std::cout << "  Etiqueta del tramo: "; std::getline(std::cin, etiq);
            std::cout << "  Distancia (km): "; std::cin >> dist;
            gestorRutas.agregarDistancia(etiq, dist);
        } else if (op == 2) {
            gestorRutas.mostrarDistancias();
        } else if (op == 3) {
            std::string orig, dest; double tiempo;
            std::cout << "  Ciudad origen: ";  std::getline(std::cin, orig);
            std::cout << "  Ciudad destino: "; std::getline(std::cin, dest);
            std::cout << "  Tiempo (hrs): ";   std::cin >> tiempo;
            gestorRutas.setTiempo(orig, dest, tiempo);
        } else if (op == 4) {
            gestorRutas.mostrarTiempos();
        } else if (op == 5) {
            std::string orig, dest; double prio;
            std::cout << "  Ciudad origen: ";  std::getline(std::cin, orig);
            std::cout << "  Ciudad destino: "; std::getline(std::cin, dest);
            std::cout << "  Prioridad (0-10): "; std::cin >> prio;
            gestorRutas.agregarRutaPrioritaria(orig, dest, prio);
        } else if (op == 6) {
            gestorRutas.mostrarMatrizDispersa();
        }
    } while (op != 0);
}

void SistemaMensajeria::mostrarResumenGeneral() {
    std::cout << "\n========================================\n";
    std::cout << "       RESUMEN GENERAL DEL SISTEMA\n";
    std::cout << "========================================\n";

    std::cout << "\n[RUTA ACTUAL]\n";
    ruta.mostrarRuta();

    std::cout << "\n[ESTADO DE PAQUETES]\n";
    gestorPaquetes.mostrarEstado();

    std::cout << "\n[POSICION DEL CAMION]\n";
    gestorRutas.mostrarPosicion();

    std::cout << "\n[DISTANCIAS 1D]\n";
    gestorRutas.mostrarDistancias();

    std::cout << "\n[TIEMPOS 2D]\n";
    gestorRutas.mostrarTiempos();

    std::cout << "\n[RUTAS PRIORITARIAS (DISPERSA)]\n";
    gestorRutas.mostrarMatrizDispersa();

    std::cout << "\n========================================\n";
}

void SistemaMensajeria::ejecutar() {
    std::cout << "=============================================\n";
    std::cout << "   SISTEMA DE GESTION DE MENSAJERIA v1.0\n";
    std::cout << "=============================================\n";

    char cargarDemo;
    std::cout << "  Cargar datos de demostracion? (s/n): ";
    std::cin >> cargarDemo;
    if (cargarDemo == 's' || cargarDemo == 'S') {
        cargarDatosDemostracion();
    }

    int op;
    do {
        std::cout << "\n+=============================================+\n";
        std::cout << "|        MENU PRINCIPAL                       |\n";
        std::cout << "+=============================================+\n";
        std::cout << "| 1. Gestion de Rutas (Lista Enlazada)        |\n";
        std::cout << "| 2. Gestion de Paquetes (Cola / Pila)        |\n";
        std::cout << "| 3. Simulacion Camion (Cola Circular)        |\n";
        std::cout << "| 4. Manejo de Matrices                       |\n";
        std::cout << "| 5. Resumen General                          |\n";
        std::cout << "| 0. Salir                                    |\n";
        std::cout << "+=============================================+\n";
        std::cout << "  Opcion: ";
        std::cin >> op;

        switch (op) {
            case 1: menuGestionRutas();    break;
            case 2: menuGestionPaquetes(); break;
            case 3: menuSimulacionCamion();break;
            case 4: menuMatrices();        break;
            case 5: mostrarResumenGeneral();break;
            case 0: std::cout << "\n  Cerrando sistema. Hasta luego.\n\n"; break;
            default: std::cout << "  [!] Opcion invalida.\n";
        }
    } while (op != 0);
}
